import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import Stripe from 'https://esm.sh/stripe@18.5.0?target=deno'
import { createClient } from 'jsr:@supabase/supabase-js@2'

Deno.serve(async (req) => {
  const authHeader = req.headers.get('Authorization')
  if (!authHeader) return new Response('Unauthorized', { status: 401 })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: authHeader } } },
  )

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return new Response('Unauthorized', { status: 401 })

  const { booking_id } = await req.json()
  const { data: booking, error } = await supabase
    .from('bookings')
    .select('id, passenger_id, amount, platform_fee, currency, ride_id, rides(driver_id, profiles(stripe_account_id))')
    .eq('id', booking_id)
    .single()

  if (error || !booking || booking.passenger_id !== user.id) return new Response('Booking not found', { status: 404 })

  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2025-08-27.basil' })
  const connectedAccount = (booking as any).rides?.profiles?.stripe_account_id
  if (!connectedAccount) return new Response('Driver payout account missing', { status: 409 })

  const amount = Math.round(Number(booking.amount) * 100)
  const fee = Math.round(Number(booking.platform_fee) * 100)

  const intent = await stripe.paymentIntents.create({
    amount,
    currency: String(booking.currency).toLowerCase(),
    automatic_payment_methods: { enabled: true },
    application_fee_amount: fee,
    transfer_data: { destination: connectedAccount },
    metadata: { booking_id: booking.id, passenger_id: user.id },
  })

  return Response.json({
    paymentIntent: intent.client_secret,
    customer: undefined,
    ephemeralKey: undefined,
    countryCode: 'NO',
  })
})
