create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  country_code text check (country_code in ('NO','SE','DK')),
  stripe_account_id text,
  rating numeric(2,1) default 5.0,
  created_at timestamptz not null default now()
);

create table if not exists public.rides (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles(id) on delete cascade,
  origin_name text not null,
  destination_name text not null,
  origin_lat double precision,
  origin_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  departure_at timestamptz not null,
  seats_available integer not null check (seats_available between 1 and 8),
  max_detour_km numeric(7,2) not null default 15,
  price_per_seat numeric(10,2) not null default 0,
  currency text not null default 'NOK' check (currency in ('NOK','SEK','DKK')),
  status text not null default 'active' check (status in ('active','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.ride_requests (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id) on delete cascade,
  origin_name text not null,
  destination_name text not null,
  origin_lat double precision,
  origin_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  earliest_departure_at timestamptz not null,
  latest_departure_at timestamptz not null,
  seats_needed integer not null default 1 check (seats_needed between 1 and 8),
  max_pickup_detour_km numeric(7,2) not null default 15,
  status text not null default 'searching' check (status in ('searching','matched','booked','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id) on delete cascade,
  passenger_id uuid not null references public.profiles(id) on delete cascade,
  seats integer not null default 1,
  amount numeric(10,2) not null,
  platform_fee numeric(10,2) not null default 0,
  currency text not null,
  payment_intent_id text,
  status text not null default 'pending' check (status in ('pending','paid','cancelled','refunded','completed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.rides enable row level security;
alter table public.ride_requests enable row level security;
alter table public.bookings enable row level security;

create policy "profiles_read_authenticated" on public.profiles for select to authenticated using (true);
create policy "profiles_update_self" on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "profiles_insert_self" on public.profiles for insert to authenticated with check ((select auth.uid()) = id);

create policy "rides_read_authenticated" on public.rides for select to authenticated using (true);
create policy "rides_insert_self" on public.rides for insert to authenticated with check ((select auth.uid()) = driver_id);
create policy "rides_update_self" on public.rides for update to authenticated using ((select auth.uid()) = driver_id) with check ((select auth.uid()) = driver_id);

create policy "requests_read_authenticated" on public.ride_requests for select to authenticated using (true);
create policy "requests_insert_self" on public.ride_requests for insert to authenticated with check ((select auth.uid()) = passenger_id);
create policy "requests_update_self" on public.ride_requests for update to authenticated using ((select auth.uid()) = passenger_id) with check ((select auth.uid()) = passenger_id);

create policy "bookings_read_party" on public.bookings for select to authenticated using (
  (select auth.uid()) = passenger_id or exists (
    select 1 from public.rides r where r.id = ride_id and r.driver_id = (select auth.uid())
  )
);
create policy "bookings_insert_passenger" on public.bookings for insert to authenticated with check ((select auth.uid()) = passenger_id);

create index if not exists rides_departure_idx on public.rides(departure_at);
create index if not exists requests_time_idx on public.ride_requests(earliest_departure_at, latest_departure_at);
