import React, { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native'
import { StatusBar } from 'expo-status-bar'
import { StripeProvider } from '@stripe/stripe-react-native'
import { isSupabaseConfigured, supabase } from './src/lib/supabase'
import { biometricAvailable, unlockWithBiometrics } from './src/lib/biometric'

type Mode = 'home' | 'search' | 'offer' | 'matches'

type DemoRequest = {
  id: string
  from: string
  to: string
  time: string
  seats: number
}

const demoRequests: DemoRequest[] = [
  { id: '1', from: 'Sandnes', to: 'Oslo', time: 'Dziś 16:00–18:00', seats: 1 },
  { id: '2', from: 'Bryne', to: 'Kristiansand', time: 'Jutro 08:00–10:00', seats: 2 },
]

export default function App() {
  const [mode, setMode] = useState<Mode>('home')
  const [authenticated, setAuthenticated] = useState(!isSupabaseConfigured)
  const [authLoading, setAuthLoading] = useState(isSupabaseConfigured)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [locked, setLocked] = useState(false)
  const [biometrics, setBiometrics] = useState(false)
  const [from, setFrom] = useState('Ålgård')
  const [to, setTo] = useState('Stavanger')
  const [date, setDate] = useState('2026-09-30 16:00')
  const [seats, setSeats] = useState('1')
  const [maxDetour, setMaxDetour] = useState('15')

  useEffect(() => {
    biometricAvailable().then(setBiometrics).catch(() => setBiometrics(false))
    if (isSupabaseConfigured) {
      supabase.auth.getSession().then(({ data }) => {
        const hasSession = Boolean(data.session)
        setAuthenticated(hasSession)
        setLocked(hasSession)
        setAuthLoading(false)
      })
      const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
        setAuthenticated(Boolean(session))
        if (session) setLocked(true)
      })
      return () => listener.subscription.unsubscribe()
    }
    setAuthLoading(false)
  }, [])

  const stripeKey = process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder'

  const title = useMemo(() => {
    if (mode === 'search') return 'Szukam przejazdu'
    if (mode === 'offer') return 'Mam wolne miejsca'
    if (mode === 'matches') return 'Pasażerowie po Twojej trasie'
    return 'Samvei'
  }, [mode])


  async function signIn() {
    if (!email || password.length < 6) return Alert.alert('Sprawdź dane', 'Podaj e-mail i hasło min. 6 znaków.')
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    if (error) Alert.alert('Nie udało się zalogować', error.message)
  }

  async function signUp() {
    if (!email || password.length < 6) return Alert.alert('Sprawdź dane', 'Podaj e-mail i hasło min. 6 znaków.')
    const { error } = await supabase.auth.signUp({ email: email.trim(), password })
    if (error) return Alert.alert('Nie udało się utworzyć konta', error.message)
    Alert.alert('Konto utworzone', 'Jeśli potwierdzanie e-mail jest włączone, sprawdź skrzynkę i potwierdź adres.')
  }

  async function signOut() {
    await supabase.auth.signOut()
    setAuthenticated(false)
    setLocked(false)
  }

  async function unlock() {
    const result = await unlockWithBiometrics()
    if (result.success) setLocked(false)
    else Alert.alert('Nie odblokowano', 'Użyj biometrii lub kodu urządzenia.')
  }

  async function savePassengerRequest() {
    if (!from || !to) return Alert.alert('Uzupełnij trasę')
    if (!isSupabaseConfigured) {
      Alert.alert('Tryb demo', `Zgłoszenie zapisane: ${from} → ${to}`)
      setMode('home')
      return
    }

    const { data: userData } = await supabase.auth.getUser()
    if (!userData.user) return Alert.alert('Zaloguj się', 'Najpierw utwórz konto lub zaloguj się.')

    const { error } = await supabase.from('ride_requests').insert({
      passenger_id: userData.user.id,
      origin_name: from,
      destination_name: to,
      earliest_departure_at: new Date(date).toISOString(),
      latest_departure_at: new Date(new Date(date).getTime() + 2 * 60 * 60 * 1000).toISOString(),
      seats_needed: Number(seats) || 1,
      max_pickup_detour_km: Number(maxDetour) || 15,
    })
    if (error) return Alert.alert('Błąd', error.message)
    Alert.alert('Gotowe', 'Kierowcy jadący podobną trasą zobaczą Twoje zgłoszenie.')
    setMode('home')
  }

  async function saveDriverRide() {
    if (!from || !to) return Alert.alert('Uzupełnij trasę')
    if (!isSupabaseConfigured) {
      Alert.alert('Tryb demo', `Trasa opublikowana: ${from} → ${to}`)
      setMode('matches')
      return
    }

    const { data: userData } = await supabase.auth.getUser()
    if (!userData.user) return Alert.alert('Zaloguj się', 'Najpierw utwórz konto lub zaloguj się.')

    const { error } = await supabase.from('rides').insert({
      driver_id: userData.user.id,
      origin_name: from,
      destination_name: to,
      departure_at: new Date(date).toISOString(),
      seats_available: Number(seats) || 1,
      max_detour_km: Number(maxDetour) || 15,
      price_per_seat: 150,
      currency: 'NOK',
    })
    if (error) return Alert.alert('Błąd', error.message)
    setMode('matches')
  }


  if (authLoading) {
    return <SafeAreaView style={styles.safe}><View style={styles.lockScreen}><Text style={styles.logo}>Samvei</Text><Text style={styles.subtitle}>Ładowanie bezpiecznej sesji…</Text></View></SafeAreaView>
  }

  if (isSupabaseConfigured && !authenticated) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="light" />
        <View style={styles.authScreen}>
          <Text style={styles.logo}>Samvei</Text>
          <Text style={styles.subtitle}>Jedno konto dla przejazdów w Norwegii, Szwecji i Danii.</Text>
          <TextInput style={styles.input} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="E-mail" placeholderTextColor="#6f7785" />
          <TextInput style={[styles.input,{marginTop:12}]} value={password} onChangeText={setPassword} secureTextEntry placeholder="Hasło" placeholderTextColor="#6f7785" />
          <TouchableOpacity style={styles.primary} onPress={signIn}><Text style={styles.primaryText}>Zaloguj się</Text></TouchableOpacity>
          <TouchableOpacity style={styles.secondaryButton} onPress={signUp}><Text style={styles.secondaryText}>Utwórz konto</Text></TouchableOpacity>
          <Text style={styles.authHint}>Po pierwszym logowaniu aplikacja może być odblokowywana Face ID, odciskiem palca lub kodem urządzenia.</Text>
        </View>
      </SafeAreaView>
    )
  }

  if (locked) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="light" />
        <View style={styles.lockScreen}>
          <Text style={styles.logo}>Samvei</Text>
          <Text style={styles.subtitle}>Twoje przejazdy są zablokowane</Text>
          <TouchableOpacity style={styles.primary} onPress={unlock}>
            <Text style={styles.primaryText}>{biometrics ? 'Odblokuj biometrią' : 'Odblokuj kodem urządzenia'}</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <StripeProvider publishableKey={stripeKey} merchantIdentifier="merchant.no.samvei.scandinavia" urlScheme="samvei">
      <SafeAreaView style={styles.safe}>
        <StatusBar style="light" />
        <ScrollView contentContainerStyle={styles.page}>
          <View style={styles.header}>
            {mode !== 'home' ? (
              <TouchableOpacity onPress={() => setMode('home')}><Text style={styles.back}>‹</Text></TouchableOpacity>
            ) : <View style={{ width: 32 }} />}
            <Text style={styles.title}>{title}</Text>
            {isSupabaseConfigured ? <TouchableOpacity onPress={signOut}><Text style={styles.logout}>Wyjdź</Text></TouchableOpacity> : <View style={{ width: 32 }} />}
          </View>

          {mode === 'home' && (
            <>
              <Text style={styles.hero}>Podróżujesz po Skandynawii?</Text>
              <Text style={styles.subtitle}>Znajdź wolne miejsce albo zabierz pasażera po swojej trasie.</Text>

              <TouchableOpacity style={styles.primaryCard} onPress={() => setMode('search')}>
                <Text style={styles.cardIcon}>🔎</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cardTitle}>Szukam przejazdu</Text>
                  <Text style={styles.cardText}>Zgłoś A → B, a kierowcy jadący podobną trasą mogą Cię zabrać.</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.card} onPress={() => setMode('offer')}>
                <Text style={styles.cardIcon}>🚗</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cardTitle}>Mam wolne miejsca</Text>
                  <Text style={styles.cardText}>Opublikuj trasę i zobacz pasażerów, których możesz zabrać po drodze.</Text>
                </View>
              </TouchableOpacity>

              <View style={styles.badgeRow}>
                <Text style={styles.badge}>🇳🇴 Norwegia</Text>
                <Text style={styles.badge}>🇸🇪 Szwecja</Text>
                <Text style={styles.badge}>🇩🇰 Dania</Text>
              </View>

              <View style={styles.securityBox}>
                <Text style={styles.securityTitle}>🔐 Bezpieczny dostęp</Text>
                <Text style={styles.cardText}>{biometrics ? 'Face ID / odcisk palca dostępny na tym urządzeniu.' : 'Biometria pojawi się automatycznie na obsługiwanym urządzeniu.'}</Text>
              </View>
            </>
          )}

          {(mode === 'search' || mode === 'offer') && (
            <View style={styles.form}>
              <Field label="Skąd" value={from} onChangeText={setFrom} placeholder="np. Stavanger" />
              <Field label="Dokąd" value={to} onChangeText={setTo} placeholder="np. Oslo" />
              <Field label="Data i godzina" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD HH:mm" />
              <Field label="Liczba osób / miejsc" value={seats} onChangeText={setSeats} keyboardType="numeric" />
              <Field label={mode === 'offer' ? 'Maksymalny objazd (km)' : 'Maks. odległość odbioru (km)'} value={maxDetour} onChangeText={setMaxDetour} keyboardType="numeric" />

              <TouchableOpacity style={styles.primary} onPress={mode === 'search' ? savePassengerRequest : saveDriverRide}>
                <Text style={styles.primaryText}>{mode === 'search' ? 'Zgłoś potrzebę przejazdu' : 'Opublikuj przejazd'}</Text>
              </TouchableOpacity>
            </View>
          )}

          {mode === 'matches' && (
            <>
              <Text style={styles.subtitle}>Zgłoszenia pasażerów, które mogą pasować do Twojej trasy:</Text>
              {demoRequests.map((r) => (
                <View key={r.id} style={styles.matchCard}>
                  <Text style={styles.cardTitle}>{r.from} → {r.to}</Text>
                  <Text style={styles.cardText}>{r.time} · {r.seats} os.</Text>
                  <Text style={styles.detour}>Szacowany objazd: 7–12 km</Text>
                  <TouchableOpacity style={styles.smallPrimary} onPress={() => Alert.alert('Zaproszenie wysłane', 'Pasażer otrzyma propozycję przejazdu.')}> 
                    <Text style={styles.primaryText}>Mogę zabrać</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </>
          )}

          <Text style={styles.footer}>{isSupabaseConfigured ? 'Backend: Supabase połączony' : 'Tryb demo — dodaj .env, aby połączyć Supabase i Stripe'}</Text>
        </ScrollView>
      </SafeAreaView>
    </StripeProvider>
  )
}

function Field(props: any) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={styles.label}>{props.label}</Text>
      <TextInput
        style={styles.input}
        placeholderTextColor="#6f7785"
        {...props}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#091014' },
  page: { padding: 20, paddingBottom: 48 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 },
  back: { color: '#76f6be', fontSize: 38, lineHeight: 40 },
  title: { color: 'white', fontSize: 20, fontWeight: '800' },
  logo: { color: '#76f6be', fontWeight: '900', fontSize: 42 },
  hero: { color: 'white', fontSize: 34, lineHeight: 40, fontWeight: '900', marginBottom: 10 },
  subtitle: { color: '#aeb7c3', fontSize: 16, lineHeight: 23, marginBottom: 22 },
  primaryCard: { backgroundColor: '#12362d', borderColor: '#2e8f70', borderWidth: 1, borderRadius: 20, padding: 18, flexDirection: 'row', gap: 14, marginBottom: 14 },
  card: { backgroundColor: '#121b21', borderColor: '#26333c', borderWidth: 1, borderRadius: 20, padding: 18, flexDirection: 'row', gap: 14, marginBottom: 14 },
  cardIcon: { fontSize: 28 },
  cardTitle: { color: 'white', fontSize: 18, fontWeight: '800', marginBottom: 5 },
  cardText: { color: '#9eabb5', fontSize: 14, lineHeight: 20 },
  badgeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8, marginBottom: 24 },
  badge: { color: '#d8e0e6', backgroundColor: '#101820', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 },
  securityBox: { backgroundColor: '#0e171c', borderRadius: 16, padding: 16 },
  securityTitle: { color: '#76f6be', fontWeight: '800', marginBottom: 7 },
  form: { backgroundColor: '#0f171c', borderRadius: 20, padding: 18 },
  label: { color: '#c6d0d8', fontWeight: '700', marginBottom: 7 },
  input: { color: 'white', backgroundColor: '#182229', borderWidth: 1, borderColor: '#2a3740', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 16 },
  primary: { backgroundColor: '#63e6ad', borderRadius: 14, paddingVertical: 15, alignItems: 'center', marginTop: 8 },
  primaryText: { color: '#04110c', fontWeight: '900', fontSize: 16 },
  matchCard: { backgroundColor: '#121b21', borderRadius: 18, padding: 17, marginBottom: 12, borderWidth: 1, borderColor: '#26333c' },
  detour: { color: '#76f6be', fontWeight: '700', marginTop: 9, marginBottom: 12 },
  smallPrimary: { backgroundColor: '#63e6ad', borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
  footer: { color: '#64717b', fontSize: 12, textAlign: 'center', marginTop: 30 },
  lockScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28 },
  authScreen: { flex: 1, justifyContent: 'center', padding: 28 },
  secondaryButton: { borderWidth: 1, borderColor: '#3c4a53', borderRadius: 14, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  secondaryText: { color: '#dce5ea', fontWeight: '800' },
  authHint: { color: '#72808a', lineHeight: 19, fontSize: 12, marginTop: 18, textAlign: 'center' },
  logout: { color: '#8f9ca5', fontWeight: '700', fontSize: 13 },
})
