import { initPaymentSheet, presentPaymentSheet } from '@stripe/stripe-react-native'
import { supabase } from './supabase'

export async function payForBooking(bookingId: string) {
  const { data, error } = await supabase.functions.invoke('create-payment-intent', {
    body: { booking_id: bookingId },
  })
  if (error) throw error

  const init = await initPaymentSheet({
    merchantDisplayName: 'Samvei Scandinavia',
    paymentIntentClientSecret: data.paymentIntent,
    customerId: data.customer,
    customerEphemeralKeySecret: data.ephemeralKey,
    applePay: { merchantCountryCode: data.countryCode || 'NO' },
    googlePay: { merchantCountryCode: data.countryCode || 'NO', testEnv: true },
    allowsDelayedPaymentMethods: false,
    returnURL: 'samvei://stripe-redirect',
  })
  if (init.error) throw init.error

  const result = await presentPaymentSheet()
  if (result.error) throw result.error
  return true
}
