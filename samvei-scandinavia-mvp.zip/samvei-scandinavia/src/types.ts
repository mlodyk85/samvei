export type Ride = {
  id: string
  driver_id: string
  origin_name: string
  destination_name: string
  origin_lat: number
  origin_lng: number
  destination_lat: number
  destination_lng: number
  departure_at: string
  seats_available: number
  price_per_seat: number
  currency: 'NOK' | 'SEK' | 'DKK'
  max_detour_km: number
  status: 'active' | 'completed' | 'cancelled'
}

export type RideRequest = {
  id: string
  passenger_id: string
  origin_name: string
  destination_name: string
  origin_lat: number
  origin_lng: number
  destination_lat: number
  destination_lng: number
  earliest_departure_at: string
  latest_departure_at: string
  seats_needed: number
  max_pickup_detour_km: number
  status: 'searching' | 'matched' | 'booked' | 'cancelled'
}
