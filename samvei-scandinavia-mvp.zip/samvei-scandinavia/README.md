# Samvei Scandinavia — MVP

Prosta aplikacja typu carpooling dla Norwegii, Szwecji i Danii.

## Funkcje
- dwa tryby: `Szukam przejazdu` i `Mam wolne miejsca`
- pasażer może zgłosić A → B, a kierowca zobaczy zgłoszenia po swojej trasie
- logowanie sesyjne przez Supabase Auth
- blokada aplikacji Face ID / odciskiem palca / kodem urządzenia
- baza: profile, przejazdy, zgłoszenia pasażerów, rezerwacje
- RLS w Supabase
- Stripe PaymentSheet gotowy pod kartę, Apple Pay i Google Pay
- Stripe Connect: prowizja platformy + wypłata do kierowcy

## Uruchomienie
1. Zainstaluj Node.js 22.13+.
2. `npm install`
3. Skopiuj `.env.example` do `.env` i uzupełnij dane Supabase oraz Stripe.
4. Uruchom migrację `supabase/migrations/001_init.sql` w projekcie Supabase.
5. W Supabase ustaw sekret `STRIPE_SECRET_KEY` dla Edge Function.
6. Wdróż `supabase/functions/create-payment-intent`.
7. `npx expo start`

Bez `.env` aplikacja uruchamia się w trybie demo, dzięki czemu można od razu obejrzeć UX.

## Produkcja
Przed publikacją należy skonfigurować:
- logowanie email/OTP lub Apple/Google w Supabase Auth,
- prawdziwy Apple Merchant ID,
- Stripe Connect onboarding kierowcy,
- webhook Stripe do potwierdzania `paid/refunded`,
- mapy/geocoding i dokładne wyliczanie objazdu,
- regulamin carpoolingu i limity kosztowe dla poszczególnych rynków.
